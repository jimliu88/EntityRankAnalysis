#!/bin/bash
java -cp ../target/csparsej-1.1.0.jar edu.emory.mathcs.csparsej.tdouble.demo.Dcs_demo1 ../src/main/resources/edu/emory/mathcs/csparsej/t1
java -cp ../target/csparsej-1.1.0.jar edu.emory.mathcs.csparsej.tdouble.demo.Dcs_demo2 ../src/main/resources/edu/emory/mathcs/csparsej/t1
java -cp ../target/csparsej-1.1.0.jar edu.emory.mathcs.csparsej.tdouble.demo.Dcs_demo2 ../src/main/resources/edu/emory/mathcs/csparsej/ash219
java -cp ../target/csparsej-1.1.0.jar edu.emory.mathcs.csparsej.tdouble.demo.Dcs_demo2 ../src/main/resources/edu/emory/mathcs/csparsej/bcsstk01
java -cp ../target/csparsej-1.1.0.jar edu.emory.mathcs.csparsej.tdouble.demo.Dcs_demo2 ../src/main/resources/edu/emory/mathcs/csparsej/fs_183_1
java -cp ../target/csparsej-1.1.0.jar edu.emory.mathcs.csparsej.tdouble.demo.Dcs_demo2 ../src/main/resources/edu/emory/mathcs/csparsej/mbeacxc
java -cp ../target/csparsej-1.1.0.jar edu.emory.mathcs.csparsej.tdouble.demo.Dcs_demo2 ../src/main/resources/edu/emory/mathcs/csparsej/west0067
java -cp ../target/csparsej-1.1.0.jar edu.emory.mathcs.csparsej.tdouble.demo.Dcs_demo2 ../src/main/resources/edu/emory/mathcs/csparsej/lp_afiro
java -cp ../target/csparsej-1.1.0.jar edu.emory.mathcs.csparsej.tdouble.demo.Dcs_demo2 ../src/main/resources/edu/emory/mathcs/csparsej/bcsstk16
java -cp ../target/csparsej-1.1.0.jar edu.emory.mathcs.csparsej.tdouble.demo.Dcs_demo3 ../src/main/resources/edu/emory/mathcs/csparsej/bcsstk01
java -cp ../target/csparsej-1.1.0.jar edu.emory.mathcs.csparsej.tdouble.demo.Dcs_demo3 ../src/main/resources/edu/emory/mathcs/csparsej/bcsstk16

